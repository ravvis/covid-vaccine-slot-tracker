export default function beep() {
  process.stdout.write("\u0007");
}
